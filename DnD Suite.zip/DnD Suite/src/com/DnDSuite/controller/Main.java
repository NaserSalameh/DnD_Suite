package com.DnDSuite.controller;

import com.DnDSuite.view.frontGUI.FrontGUI;

public class Main {

    public static void main(String[] args){

        FrontGUI frontGUI = new FrontGUI();

    }

}
